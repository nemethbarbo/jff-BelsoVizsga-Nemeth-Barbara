import { Component } from '@angular/core';

@Component({
  selector: 'app-vizsgafeladat',
  templateUrl: './vizsgafeladat.component.html',
  styleUrls: ['./vizsgafeladat.component.css']
})
export class VizsgafeladatComponent {
  bmi: number = 1;
  height: number = 1;
  weight: number = 1;

  bmiCalculate(): number {
    return (this.weight / Math.pow((this.height / 100), 2));
  }

  EredmenyMentes(){
    let bmi:number = this.bmiCalculate();
    this.eredmenylista.push(`A(z) ${this.weight} testsúlyú és  ${this.height} magasságú ember testtömeg indexe:  ${this.bmiCalculate()}`);
  }

  eredmenylista: string[] = [];
}
