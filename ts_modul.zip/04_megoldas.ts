function EkezetesBetukSzama(vizsgaltSzoveg:string): number {
    let ekezetesBetuk: string[] = ["á", "é", "í", "ó", "ö", "ő", "ú", "ü", "ű"];
    let ekezetesBetukDb: number = 0;
    vizsgaltSzoveg = vizsgaltSzoveg.toLowerCase();
    for (let i:number = 0; i < vizsgaltSzoveg.length; i++) {
           for (let j:number = 0; j < ekezetesBetuk.length; j++) {
                if (vizsgaltSzoveg[i] == ekezetesBetuk[j]) {
                    ekezetesBetukDb++;
                }
            }
        }
    return ekezetesBetukDb;
}

function ElsoNszamSzorzat(mennyiseg:number): number {
    var osszeg = 1; 
    for (var i = 1; i <= mennyiseg; i++) {
        osszeg *= i; 
    }
    return osszeg;
}

function ParosakOsszege(vizsgaltTomb:number[]):number {
    let parosOsszeg:number = 0;
    for (let i:number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i]%2==0) {
            parosOsszeg+=vizsgaltTomb[i];
        }
    }
    return parosOsszeg;
}