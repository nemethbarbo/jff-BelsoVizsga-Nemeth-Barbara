function EkezetesBetukSzama(vizsgaltSzoveg) {
    var ekezetesBetuk = ["á", "é", "í", "ó", "ö", "ő", "ú", "ü", "ű"];
    var ekezetesBetukDb = 0;
    vizsgaltSzoveg = vizsgaltSzoveg.toLowerCase();
    for (var i = 0; i < vizsgaltSzoveg.length; i++) {
        for (var j = 0; j < ekezetesBetuk.length; j++) {
            if (vizsgaltSzoveg[i] == ekezetesBetuk[j]) {
                ekezetesBetukDb++;
            }
        }
    }
    return ekezetesBetukDb;
}
function ElsoNszamSzorzat(mennyiseg) {
    var osszeg = 1;
    for (var i = 1; i <= mennyiseg; i++) {
        osszeg *= i;
    }
    return osszeg;
}
function ParosakOsszege(vizsgaltTomb) {
    var parosOsszeg = 0;
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] % 2 == 0) {
            parosOsszeg += vizsgaltTomb[i];
        }
    }
    return parosOsszeg;
}
